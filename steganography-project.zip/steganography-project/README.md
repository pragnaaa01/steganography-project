
# 🕵️ Steganography Tool (LSB Image Encoding)

A simple Python project to hide and extract secret messages from images using Least Significant Bit (LSB) method.

## 📦 Requirements
- Python 3.x
- Pillow

Install dependencies:
```bash
pip install -r requirements.txt
```

## 🔐 Usage

### Encode a Message
```bash
python encode.py
```

### Decode a Message
```bash
python decode.py
```

## 🧪 Sample Files
See the `samples/` folder for input/output images.

## 📄 License
MIT License
