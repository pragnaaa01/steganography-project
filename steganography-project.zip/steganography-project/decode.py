
from PIL import Image

def decode_image(image_path):
    image = Image.open(image_path)
    pixels = list(image.getdata())

    binary_message = ''
    for pixel in pixels:
        for i in range(3):  # RGB
            binary_message += str(pixel[i] & 1)

    chars = [binary_message[i:i+8] for i in range(0, len(binary_message), 8)]
    message = ''
    for c in chars:
        if c == '11111110':
            break
        message += chr(int(c, 2))

    print("Hidden message:", message)

if __name__ == "__main__":
    decode_image("samples/secret.png")
