
from PIL import Image

def encode_image(image_path, message, output_path):
    image = Image.open(image_path)
    binary_message = ''.join(format(ord(i), '08b') for i in message) + '1111111111111110'
    pixels = list(image.getdata())

    new_pixels = []
    msg_index = 0

    for pixel in pixels:
        new_pixel = list(pixel)
        for i in range(3):  # RGB
            if msg_index < len(binary_message):
                new_pixel[i] = new_pixel[i] & ~1 | int(binary_message[msg_index])
                msg_index += 1
        new_pixels.append(tuple(new_pixel))

    image.putdata(new_pixels)
    image.save(output_path)
    print(f"Message encoded and saved to {output_path}")

if __name__ == "__main__":
    encode_image("samples/original.png", "Hello, this is secret!", "samples/secret.png")
